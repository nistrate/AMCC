/*
 * myDCMotorLibrary.cpp - A library for first arduino project
 * Created by Nicolae Istrate on 2/1/2022
 * First Draft
 */

 // source: https://core-electronics.com.au/tutorials/how-to-build-an-arduino-library.html

//  The #include of Arduino.h gives this library access to the standard
//  Arduino types and constants (HIGH, digitalWrite, etc.). It's 
//  unneccesary for sketches but required for libraries as they're not
//  .ino (Arduino) files. 
#include "Arduino.h"

//  This will include the Header File so that the Source File has access
//  to the function definitions in the myFirstLibrary library.
#include "myDCMotorLibrary.h" 



//  This is where the constructor Source Code appears. The '::' indicates that
//  it is part of the myFirstLibrary class and should be used for all constructors
//  and functions that are part of a class.
myDCMotorLibrary::myDCMotorLibrary(int LeftBackIO, int LeftBackA, int LeftBackB, int RightBackIO, int RightBackA, int RightBackB, int FrontIO, int FrontA, int FrontB)
{
  //  This is where the pinModes are defined for circuit operation.
  pinMode(LeftBackIO,OUTPUT);
  pinMode(LeftBackA,OUTPUT);
  pinMode(LeftBackB,OUTPUT);
  pinMode(RightBackIO,OUTPUT);
  pinMode(RightBackA,OUTPUT);
  pinMode(RightBackB,OUTPUT);
  pinMode(FrontIO,OUTPUT);
  pinMode(FrontA,OUTPUT);
  pinMode(FrontB,OUTPUT);

  //  The arguments of the constructor are then saved into the private variables.
  _LeftBackIO = LeftBackIO;
  _LeftBackA = LeftBackA;
  _LeftBackB = LeftBackB;
  
  _RightBackIO = RightBackIO;
  _RightBackA = RightBackA;
  _RightBackB = RightBackB;
  
  _FrontIO = FrontIO;
  _FrontA = FrontA;
  _FrontB = FrontB;
}

//  For the 'on', 'off' and 'flash' functions, their function return type (void) is
//  specified before the class-function link. They also use the private variables
//  saved in the constructor code.

void myDCMotorLibrary::PowerBack(int voltageLeft,int voltageRight)
{
  analogWrite(_LeftBackIO, voltageLeft);
  analogWrite(_RightBackIO, voltageRight);
}

// NOTE : CW and CCW
//        wrt looking at device facing right
//        seeing front of right wheel 


void myDCMotorLibrary::RightBackCW()
{
  digitalWrite(_RightBackA, HIGH);
  digitalWrite(_RightBackB, LOW);
}

void myDCMotorLibrary::RightBackCCW()
{
  digitalWrite(_RightBackA, LOW);
  digitalWrite(_RightBackB, HIGH);
}

void myDCMotorLibrary::LeftBackCW()
{
  digitalWrite(_LeftBackA, HIGH);
  digitalWrite(_LeftBackB, LOW);
}


void myDCMotorLibrary::LeftBackCCW()
{
  digitalWrite(_LeftBackA, LOW);
  digitalWrite(_LeftBackB, HIGH);
}


void myDCMotorLibrary::endSignalRightBack()
{
  digitalWrite(_RightBackA, LOW);
  digitalWrite(_RightBackB, LOW);
}

void myDCMotorLibrary::endSignalLeftBack()
{
  digitalWrite(_LeftBackA, LOW);
  digitalWrite(_LeftBackB, LOW);
}

void myDCMotorLibrary::PowerOffBack()
{
  endSignalLeftBack();
  endSignalRightBack();
  PowerBack(0,0); 
}

/////////////////////////////////////////////////////////


// Front DC Motor ( left right)

// NOTE : CW and CCW
//        wrt looking at the back of the device


void myDCMotorLibrary::PowerFront(int voltageFront)
{
  digitalWrite(_FrontIO, voltageFront);
}

void myDCMotorLibrary::FrontCW() // left turn
{
  digitalWrite(_FrontA, HIGH);
  digitalWrite(_FrontB, LOW);
}


void myDCMotorLibrary::FrontCCW() // right turn
{
  digitalWrite(_FrontA, LOW);
  digitalWrite(_FrontB, HIGH);
}

void myDCMotorLibrary::endSignalFront()
{
  digitalWrite(_FrontA, LOW);
  digitalWrite(_FrontB, LOW);
}

void myDCMotorLibrary::PowerOffFront()
{
  endSignalFront();
  PowerFront(LOW);
  
}

//////////////////////
/////////////////////
void myDCMotorLibrary::PowerOff()
{
  PowerOffBack();
  PowerOffFront();
}


/////////////////////////////////////////////////////////

//////////////////////////
// Basic Motions (from primitives)

////////////////////////
///  Verified

void myDCMotorLibrary::backLeftForward(int duration)
{
  PowerBack(HIGH,LOW);
  LeftBackCW();

  
  delay(duration);

  //Powering Off
  PowerOff();
  
  delay(1000);

}

void myDCMotorLibrary::backLeftBackward(int duration)
{
  PowerBack(HIGH,LOW);
  LeftBackCCW();
  
  delay(duration);

  //Powering Off
  PowerOff();
  
  delay(1000);


}

void myDCMotorLibrary::backRightForward(int duration)
{
  PowerBack(LOW,HIGH);
  RightBackCW();
  
  delay(duration);

  //Powering Off
  PowerOff();
  
  delay(1000);

}

void myDCMotorLibrary::backRightBackward(int duration)
{
  PowerBack(LOW,HIGH);
  RightBackCCW();

  
  delay(duration);

  //Powering Off
  PowerOff();
  
  delay(1000);

}

// Move Forward and Backwards

void myDCMotorLibrary::forward(int voltage)
{
  //Powering up back wheels
  PowerBack(voltage,voltage);
  
  RightBackCW();
  LeftBackCW();
}

void myDCMotorLibrary::backward(int duration, int voltage)
{
  //Powering up back wheels
  PowerBack(voltage,voltage);
  
  RightBackCCW();
  LeftBackCCW();
  delay(duration);

  //Powering Off
  myDCMotorLibrary::PowerOff();
  
  delay(1000);
}


//Left and Right Turns (forward motion)

void myDCMotorLibrary::leftForwardTurn(int duration)
{
  PowerFront(HIGH);
  PowerBack(255,255);
  
  FrontCW();
  delay(500);
  RightBackCW();
  LeftBackCCW();
  delay(duration);
  
  PowerOff();

  delay(1000);
  
}



void myDCMotorLibrary::rightForwardTurn(int duration)
{
  PowerFront(HIGH);
  PowerBack(255,255);
  
  FrontCCW();
  delay(500);
  LeftBackCW();
  RightBackCCW();
  delay(duration);
  
  PowerOff();

  delay(1000);
  
}

