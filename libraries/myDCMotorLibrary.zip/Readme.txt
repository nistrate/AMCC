my DC motor library
